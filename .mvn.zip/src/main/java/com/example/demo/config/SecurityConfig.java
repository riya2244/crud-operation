package com.example.demo.config;

import org.springframework.context.annotation.Bean;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@EnableWebSecurity
public class SecurityConfig {
    
    @Bean
    public BCryptPasswordEncoder bCryptPasswordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        return http
           .csrf(csrf -> csrf.disable())
           .authorizeRequests(authorizeRequests -> authorizeRequests
               .antMatchers("/public/**").permitAll() // Allow access to public resources
               .anyRequest().authenticated() // All other URLs require authentication
           )
           .formLogin(formLogin -> formLogin
               .loginPage("/login") // Specify the custom login page URL
               .defaultSuccessUrl("/dashboard", true) // Redirect to this URL after successful login
               .permitAll() // Allow access to login page without authentication
           )
           .logout(logout -> logout
               .logoutUrl("/logout") // Specify custom logout URL
               .logoutSuccessUrl("/login?logout") // Redirect to this URL after logout
               .permitAll() // Allow access to logout URL without authentication
           )
           .build(); // Return the SecurityFilterChain instance
    }
}